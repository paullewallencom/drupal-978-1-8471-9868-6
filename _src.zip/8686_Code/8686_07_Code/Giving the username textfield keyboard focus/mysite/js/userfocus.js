Drupal.behaviors.mysiteUserFocus = function(context) {
  // console.log($('input#edit-name'));
  $('input#edit-name').focus();
}

