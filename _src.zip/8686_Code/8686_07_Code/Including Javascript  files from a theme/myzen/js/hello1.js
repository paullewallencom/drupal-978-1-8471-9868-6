if (Drupal.jsEnabled) {
  $(document).ready(function () {
    alert("Hello World!!");
  });
}
