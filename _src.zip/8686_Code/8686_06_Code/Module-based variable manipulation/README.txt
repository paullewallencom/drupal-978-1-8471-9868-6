The mysite folder represents the mysite module.
mytheme represents a typical theme whose node.tpl.php file we are editing.